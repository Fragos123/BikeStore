/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexiones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SqlConexion {

    public Connection getConexion() {
        String connectionUrl = 
            "jdbc:sqlserver://localhost:1433;" +   // servidor y puerto de SQL Server
            "databaseName=LoginDB;" +             // tu base de datos
            "user=sa;" +                          // usuario SQL
            "password=Conexion123_;" +            // contraseña
            "encrypt=false;" +                    // desactiva SSL para evitar problemas
            "trustServerCertificate=true;";       // confía en el certificado

        try {
            Connection con = DriverManager.getConnection(connectionUrl);
            System.out.println("✅ Conexión exitosa a SQL Server");
            return con;
        } catch (SQLException ex) {
            System.out.println("❌ Error en la conexión");
            ex.printStackTrace();
            return null;
        }
    }
}
