<?php
require 'config.php';
if (!isset($_SESSION['user_id']) || !isAdmin()) {
    header('Location: index.php');
    exit();
}

$id = intval($_GET['id']);
$producto = $conn->query("SELECT * FROM productos WHERE id = $id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    
    $stmt = $conn->prepare("UPDATE productos SET nombre=?, descripcion=?, precio=?, stock=? WHERE id=?");
    $stmt->bind_param("ssdii", $nombre, $descripcion, $precio, $stock, $id);
    $stmt->execute();
    
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
</head>
<body>
    <h2>Editar Producto</h2>
    <form method="POST">
        <input type="text" name="nombre" value="<?php echo $producto['nombre']; ?>" required><br><br>
        <textarea name="descripcion"><?php echo $producto['descripcion']; ?></textarea><br><br>
        <input type="number" step="0.01" name="precio" value="<?php echo $producto['precio']; ?>" required><br><br>
        <input type="number" name="stock" value="<?php echo $producto['stock']; ?>"><br><br>
        <button type="submit">Actualizar</button>
        <a href="index.php">Cancelar</a>
    </form>
</body>
</html>