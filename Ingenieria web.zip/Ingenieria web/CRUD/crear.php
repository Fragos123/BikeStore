<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("INSERT INTO productos (nombre, descripcion, precio, stock, created_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdii", $nombre, $descripcion, $precio, $stock, $user_id);
    $stmt->execute();
    
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Crear Producto</title>
</head>
<body>
    <h2>Nuevo Producto</h2>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre" required><br><br>
        <textarea name="descripcion" placeholder="Descripción"></textarea><br><br>
        <input type="number" step="0.01" name="precio" placeholder="Precio" required><br><br>
        <input type="number" name="stock" placeholder="Stock" value="0"><br><br>
        <button type="submit">Guardar</button>
        <a href="index.php">Cancelar</a>
    </form>
</body>
</html>