<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['delete']) && isAdmin()) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM productos WHERE id = $id");
    header('Location: index.php');
    exit();
}

$productos = $conn->query("SELECT * FROM productos ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h2>Bienvenido: <?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['rol']; ?>)</h2>
    <a href="logout.php">Cerrar sesión</a>
    <hr>
    
    <h3>Productos</h3>
    <a href="crear.php">+ Agregar Producto</a>
    
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Acciones</th>
        </tr>
        <?php while($p = $productos->fetch_assoc()): ?>
        <tr>
            <td><?php echo $p['id']; ?></td>
            <td><?php echo $p['nombre']; ?></td>
            <td><?php echo $p['descripcion']; ?></td>
            <td>$<?php echo $p['precio']; ?></td>
            <td><?php echo $p['stock']; ?></td>
            <td>
                <?php if(isAdmin()): ?>
                    <a href="editar.php?id=<?php echo $p['id']; ?>">Editar</a>
                    <a href="index.php?delete=<?php echo $p['id']; ?>" onclick="return confirm('¿Eliminar?')">Eliminar</a>
                <?php else: ?>
                    Solo lectura
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>