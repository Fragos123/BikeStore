<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'crud_database');
if ($conn->connect_error) die("Error: " . $conn->connect_error);
$conn->set_charset("utf8");

function isAdmin() {
    return isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin';
}
?>