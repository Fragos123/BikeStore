/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.login.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
    
    // Configuración de la base de datos
    private static final String DB_URL = "jdbc:mysql://localhost:3306/login_sistema";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "admin"; // Tu contraseña de MySQL
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // 1. Capturar valores enviados desde el formulario
            String usuario = request.getParameter("usuario");
            String password = request.getParameter("password");
            
            System.out.println("=== INICIO VALIDACIÓN BACKEND ===");
            System.out.println("Usuario recibido: " + usuario);
            System.out.println("Password recibido: [OCULTO POR SEGURIDAD]");
            System.out.println("Longitud del password: " + password.length());
            
            // 2. Validaciones básicas
            if (usuario == null || usuario.trim().isEmpty()) {
                System.out.println("❌ Error: Usuario vacío");
                mostrarRespuestaError(out, "El campo usuario es obligatorio");
                return;
            }
            
            if (password == null || password.trim().isEmpty()) {
                System.out.println("❌ Error: Password vacío");
                mostrarRespuestaError(out, "El campo contraseña es obligatorio");
                return;
            }
            
            // 3. Validar formato de email
            if (!validarEmail(usuario)) {
                System.out.println("❌ Error: Formato de email inválido");
                mostrarRespuestaError(out, "El formato del correo electrónico no es válido");
                return;
            }
            
            // 4. Validar formato de contraseña
            if (!validarPassword(password)) {
                System.out.println("❌ Error: Formato de contraseña inválido");
                mostrarRespuestaError(out, "La contraseña no cumple con los requisitos de seguridad");
                return;
            }
            
            System.out.println("✅ Validaciones de formato exitosas");
            
            // 5. Conexión a la base de datos
            System.out.println("🔗 Conectando a la base de datos...");
            boolean autenticacionExitosa = validarCredencialesEnBD(usuario, password);
            
            if (autenticacionExitosa) {
                System.out.println("🎉 ¡Autenticación exitosa!");
                mostrarRespuestaExito(out, usuario);
            } else {
                System.out.println("❌ Credenciales incorrectas");
                mostrarRespuestaError(out, "Usuario o contraseña incorrectos");
            }
            
        } catch (Exception e) {
            System.out.println("💥 Error en el servidor: " + e.getMessage());
            e.printStackTrace();
            mostrarRespuestaError(out, "Error interno del servidor: " + e.getMessage());
        } finally {
            System.out.println("=== FIN VALIDACIÓN BACKEND ===");
            out.close();
        }
    }
    
    /**
     * Valida el formato de email
     */
    private boolean validarEmail(String email) {
        System.out.println("📧 Validando formato de email...");
        String emailRegex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        boolean esValido = email.matches(emailRegex);
        System.out.println("📧 Email válido: " + esValido);
        return esValido;
    }
    
    /**
     * Valida el formato de contraseña
     */
    private boolean validarPassword(String password) {
        System.out.println("🔒 Validando formato de contraseña...");
        
        boolean longitud = password.length() >= 8;
        boolean mayuscula = password.matches(".*[A-Z].*");
        boolean minuscula = password.matches(".*[a-z].*");
        boolean numero = password.matches(".*[0-9].*");
        
        System.out.println("  - Longitud >= 8: " + longitud);
        System.out.println("  - Tiene mayúscula: " + mayuscula);
        System.out.println("  - Tiene minúscula: " + minuscula);
        System.out.println("  - Tiene número: " + numero);
        
        boolean esValida = longitud && mayuscula && minuscula && numero;
        System.out.println("🔒 Contraseña válida: " + esValida);
        
        return esValida;
    }
    
    /**
     * Valida las credenciales en la base de datos
     */
    private boolean validarCredencialesEnBD(String usuario, String password) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            System.out.println("🔗 Estableciendo conexión a MySQL...");
            
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establecer conexión
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("✅ Conexión a base de datos exitosa");
            
            // Preparar consulta SQL
            String sql = "SELECT password FROM usuarios WHERE usuario = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, usuario);
            
            System.out.println("🔍 Buscando usuario en base de datos: " + usuario);
            
            // Ejecutar consulta
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String passwordBD = rs.getString("password");
                System.out.println("👤 Usuario encontrado en base de datos");
                System.out.println("🔐 Comparando contraseñas...");
                
                // En producción deberías usar hash (BCrypt), aquí comparamos directamente
                boolean credencialesCorrectas = password.equals(passwordBD);
                System.out.println("✅ Credenciales correctas: " + credencialesCorrectas);
                
                return credencialesCorrectas;
            } else {
                System.out.println("❌ Usuario no encontrado en base de datos");
                return false;
            }
            
        } catch (ClassNotFoundException e) {
            System.out.println("💥 Error: Driver MySQL no encontrado - " + e.getMessage());
            System.out.println("🔧 Solución: Agregar mysql-connector-java al proyecto");
            return false;
        } catch (SQLException e) {
            System.out.println("💥 Error de base de datos: " + e.getMessage());
            return false;
        } finally {
            // Cerrar conexiones
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
                System.out.println("🔒 Conexiones a BD cerradas correctamente");
            } catch (SQLException e) {
                System.out.println("⚠️ Error al cerrar conexiones: " + e.getMessage());
            }
        }
    }
    
    /**
     * Muestra página de éxito
     */
    private void mostrarRespuestaExito(PrintWriter out, String usuario) {
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Login Exitoso</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #27ae60, #2ecc71); margin: 0; padding: 50px; }");
        out.println(".container { max-width: 500px; margin: 0 auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); text-align: center; }");
        out.println("h1 { color: #27ae60; margin-bottom: 1rem; }");
        out.println(".success-icon { font-size: 4rem; color: #27ae60; margin-bottom: 1rem; }");
        out.println("p { color: #333; margin-bottom: 1rem; }");
        out.println("a { display: inline-block; background: #27ae60; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 1rem; }");
        out.println("a:hover { background: #219a52; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='success-icon'>✅</div>");
        out.println("<h1>¡Bienvenido!</h1>");
        out.println("<p><strong>Autenticación exitosa</strong></p>");
        out.println("<p>Usuario: <strong>" + usuario + "</strong></p>");
        out.println("<p>Has iniciado sesión correctamente en el sistema.</p>");
        out.println("<a href='index.html'>Volver al login</a>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
    
    /**
     * Muestra página de error
     */
    private void mostrarRespuestaError(PrintWriter out, String mensaje) {
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Error de Autenticación</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #e74c3c, #c0392b); margin: 0; padding: 50px; }");
        out.println(".container { max-width: 500px; margin: 0 auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); text-align: center; }");
        out.println("h1 { color: #e74c3c; margin-bottom: 1rem; }");
        out.println(".error-icon { font-size: 4rem; color: #e74c3c; margin-bottom: 1rem; }");
        out.println("p { color: #333; margin-bottom: 1rem; }");
        out.println("a { display: inline-block; background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 1rem; }");
        out.println("a:hover { background: #c0392b; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='error-icon'>❌</div>");
        out.println("<h1>Error de Autenticación</h1>");
        out.println("<p><strong>" + mensaje + "</strong></p>");
        out.println("<p>Por favor, verifica tus credenciales e intenta nuevamente.</p>");
        out.println("<a href='index.html'>Volver al login</a>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}