/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginapp1;

import Conexiones.SqlConexion;   // importa tu clase de conexión
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginApp1 {

    // Método para validar usuario y contraseña
    public static boolean validarLogin(String usuario, String password) {
        boolean valido = false;

        try {
            SqlConexion conexion = new SqlConexion();   // crear objeto
            Connection conn = conexion.getConexion();   // usar método de instancia

            String sql = "SELECT * FROM Usuarios WHERE usuario = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                valido = true;
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("⚠️ Error en la validación: " + e.getMessage());
        }

        return valido;
    }

    public static void main(String[] args) {
        // Datos de prueba
        String correo = "fernando@ejemplo.com";
        String clave = "Prueba123";

        if (validarLogin(correo, clave)) {
            System.out.println("✅ Login exitoso, bienvenido " + correo);
        } else {
            System.out.println("❌ Usuario o contraseña incorrectos");
        }
    }
}
